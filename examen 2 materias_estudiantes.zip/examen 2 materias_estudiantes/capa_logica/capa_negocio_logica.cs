﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace capa_negocio_logica
{
    public class capa_negocio_logica
    {
        public int id_producto { get; set;}
        public string nombre { get; set; }
        public string categoria { get; set; }
        public float cantidad { get; set; }
        public decimal precio { get; set; }
        public decimal Total { get { return precio * (decimal)cantidad; } }

    }
}

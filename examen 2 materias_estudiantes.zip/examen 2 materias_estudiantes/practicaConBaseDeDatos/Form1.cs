﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using capa_negocio_logica;
using capa_datos;
using System.Data.SqlClient;

namespace practicaConBaseDeDatos
{
    /*Crear una aplicacion en C# de estudiantes y materias, la aplicacion debe tener un mantenimiento de materias y alumnos (CRUD).

La clase materias debe tener los siguientes atributos: Codigo, Nombre materia, creditos.

La clase alumno debe tener los siguientes atributos: Nombre, Apellido, Materias, Estado (Activo o Inactivo).*/


    public partial class Form1 : Form
    {
        

        public Form1()
        {
            InitializeComponent();
            mostrarDatos1();
            mostrarDatos2();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        
        public void mostrarDatos1()
        {
            conexionSQL abc = new conexionSQL();
            abc.da= new SqlDataAdapter("select * from alumno", abc.sqlc);
            abc.dt= new DataTable();
            abc.da.Fill(abc.dt);
            dgvDatos.DataSource=abc.dt;


        }

        public void mostrarDatos2()
        {
            conexionSQL abcc = new conexionSQL();
            abcc.da = new SqlDataAdapter("select * from materia", abcc.sqlc);
            abcc.dt = new DataTable();
            abcc.da.Fill(abcc.dt);
            dgvMateria.DataSource = abcc.dt;


        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            conexionSQL abc = new conexionSQL();
            abc.sqlc.Open();
            abc.sqlcmd = new SqlCommand("insert into alumno values('" + txtIDProducto.Text + "','" + txtNombre.Text + "','" + txtCategoria.Text + "','" + txtPrecio.Text + "',GETDATE())", abc.sqlc); 
            abc.sqlcmd.ExecuteNonQuery();
            MessageBox.Show("se guardaron los datos");
            abc.sqlc.Close();
            limpiar();
            mostrarDatos1();
            txtIDProducto.Focus();
        }

        
        void eliminar()
        {
            conexionSQL abc = new conexionSQL();
            abc.sqlc.Open();
            abc.sqlcmd = new SqlCommand("delete from alumno where id_alumno=" + Convert.ToInt32(this.txtIDProducto.Text + ""), abc.sqlc);
            abc.sqlcmd.ExecuteNonQuery();
            MessageBox.Show("registro eliminado");
            limpiar();
            abc.sqlc.Close();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            eliminar();
            mostrarDatos1();
            
            
        }

        public void limpiar()
        {
            proceso limpiando = new proceso();
            limpiando.id_producto= txtIDProducto.Text = "";
            limpiando.nombre=txtNombre.Text = "";
            limpiando.categoria=txtCategoria.Text = "";
            limpiando.precio= txtPrecio.Text = "";
            limpiando.cantidad= txtCantidad.Text = "";
            
        }

        public void limpiarr()
        {
            txtCodigoM.Text = "";
            txtNM.Text = "";
            txtCreditosM.Text = "";
            

        }

        private void dgvDatos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectedRow = dgvDatos.Rows[index];
            txtIDProducto.Text = selectedRow.Cells[0].Value.ToString();
            txtNombre.Text = selectedRow.Cells[1].Value.ToString();
            txtCategoria.Text = selectedRow.Cells[2].Value.ToString();
            txtPrecio.Text = selectedRow.Cells[3].Value.ToString();
            txtCantidad.Text = selectedRow.Cells[4].Value.ToString();
            
        }


        void modificar()
        {
            string query = "update alumno set nombre=@nombre,apellido=@apellido,nombreMateria=@nombreMateria,estado=@estado where id_alumno=@id_alumno";
            conexionSQL abc = new conexionSQL();
            abc.sqlc.Open();
            abc.sqlcmd = new SqlCommand(query, abc.sqlc);
            abc.sqlcmd.Parameters.AddWithValue("@id_alumno", txtIDProducto.Text);
            abc.sqlcmd.Parameters.AddWithValue("@nombre", txtNombre.Text);
            abc.sqlcmd.Parameters.AddWithValue("@apellido", txtCategoria.Text);
            abc.sqlcmd.Parameters.AddWithValue("@nombreMateria", txtPrecio.Text);
            abc.sqlcmd.Parameters.AddWithValue("@estado", txtCantidad.Text);
            abc.sqlcmd.ExecuteNonQuery();
            MessageBox.Show("datos modificados");
            mostrarDatos1();
            
        }


        void modificarr()
        {
            string queryy = "update materia set nombreMateria=@nombreMateria,creditos=@creditos where codigo=@codigo";
            conexionSQL abcc = new conexionSQL();
            abcc.sqlcc.Open();
            abcc.sqlcmd = new SqlCommand(queryy, abcc.sqlcc);
            abcc.sqlcmd.Parameters.AddWithValue("@codigo", txtCodigoM.Text);
            abcc.sqlcmd.Parameters.AddWithValue("@nombreMateria", txtNM.Text);
            abcc.sqlcmd.Parameters.AddWithValue("@creditos", txtCreditosM.Text);
            abcc.sqlcmd.ExecuteNonQuery();
            MessageBox.Show("datos modificados");
            mostrarDatos2();

        }

        int selectedRow;
        private void btnModificar_Click(object sender, EventArgs e)
        {
            
            modificar();
            limpiar();
            txtIDProducto.Focus();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            txtIDProducto.Focus();
            limpiar();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void dgvMateria_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectedRow = dgvMateria.Rows[index];
            txtCodigoM.Text = selectedRow.Cells[0].Value.ToString();
            txtNM.Text = selectedRow.Cells[1].Value.ToString();
            txtCreditosM.Text = selectedRow.Cells[2].Value.ToString();
            
        }

        private void btnCrearM_Click(object sender, EventArgs e)
        {
            conexionSQL abcc = new conexionSQL();
            abcc.sqlcc.Open();
            abcc.sqlcmd = new SqlCommand("insert into materia values('" + txtCodigoM.Text + "','" + txtNM.Text + "','" + txtCreditosM.Text + "'", abcc.sqlcc);
            abcc.sqlcmd.ExecuteNonQuery();
            MessageBox.Show("se guardaron los datos");
            abcc.sqlc.Close();
            limpiar();
            mostrarDatos2();
            txtCreditosM.Focus();
        }

        private void txtModificarM_Click(object sender, EventArgs e)
        {
            modificarr();
            limpiar();
            txtCodigoM.Focus();
        }

        private void btnNuevoM_Click(object sender, EventArgs e)
        {
            txtCodigoM.Focus();
            limpiarr();
        }
    }
}

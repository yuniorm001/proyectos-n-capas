﻿using System.Data;
using System.Data.SqlClient;

namespace capa_datos
{
    public class conexionSQL
    {
        public SqlConnection sqlc=new SqlConnection("Data Source=.;Initial Catalog=estudianteM;Integrated Security=True");
        public SqlConnection sqlcc = new SqlConnection("Data Source=.;Initial Catalog=estudianteM;Integrated Security=True");
        public SqlCommand sqlcmd;
        public DataTable dt;
        public SqlDataAdapter da;




        

    }

}
